﻿#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

typedef struct MeciVolei {
    char* codMeci;
    char* echipaGazda;
    char* echipaOaspete;
    int scorGazda;
    int scorOaspete;
} MeciVolei;

typedef struct MaxHeap {
    MeciVolei** vector;
    int dimensiune;
} MaxHeap;


MeciVolei* initializareMeci(const char* cod, const char* gazda, const char* oaspete, int scorG, int scorO) {
    MeciVolei* m = (MeciVolei*)malloc(sizeof(MeciVolei));

    m->codMeci = (char*)malloc(strlen(cod) + 1);
    strcpy(m->codMeci, cod);

    m->echipaGazda = (char*)malloc(strlen(gazda) + 1);
    strcpy(m->echipaGazda, gazda);

    m->echipaOaspete = (char*)malloc(strlen(oaspete) + 1);
    strcpy(m->echipaOaspete, oaspete);

    m->scorGazda = scorG;
    m->scorOaspete = scorO;

    return m;
}


int diferentaScor(MeciVolei* m) {
    return abs(m->scorGazda - m->scorOaspete);
}

void filtrareHeap(MeciVolei** vector, int dim, int i) {
    int max = i, left = 2 * i + 1, right = 2 * i + 2;
    if (left < dim && diferentaScor(vector[left]) > diferentaScor(vector[max]))
        max = left;
    if (right < dim && diferentaScor(vector[right]) > diferentaScor(vector[max]))
        max = right;
    if (max != i) {
        MeciVolei* temp = vector[i];
        vector[i] = vector[max];
        vector[max] = temp;
        filtrareHeap(vector, dim, max);
    }
}

void afisareHeap(MaxHeap* heap) {
    for (int i = 0; i < heap->dimensiune; i++) {
        MeciVolei* m = heap->vector[i];
        printf("%s %s vs %s  %d-%d  Diferenta: %d\n",
            m->codMeci, m->echipaGazda, m->echipaOaspete,
            m->scorGazda, m->scorOaspete, diferentaScor(m));
    }
}

// Sa se elimine toate meciurile care au fost dezechilibrate, adica diferenta de scor dintre cele doua echipe este mai mare decat un prag dat.

int numaraMeciuriCuScorPeste(MaxHeap* heap, int prag) {
    int count = 0;
    for (int i = 0; i < heap->dimensiune; i++) {
        if (heap->vector[i]->scorGazda > prag || heap->vector[i]->scorOaspete > prag)
            count++;
    }
    return count;
}

MaxHeap* stergeMeciuriEchilibrate(MaxHeap* heap) {
    int j = 0;
    for (int i = 0; i < heap->dimensiune; i++) {
        if (diferentaScor(heap->vector[i]) > 2) {
            heap->vector[j++] = heap->vector[i];
        }
    }
    heap->dimensiune = j;
    for (int i = heap->dimensiune / 2 - 1; i >= 0; i--)
        filtrareHeap(heap->vector, heap->dimensiune, i);
    return heap;
}

int main() {
    MaxHeap* heap = malloc(sizeof(MaxHeap));
    heap->dimensiune = 0;
    heap->vector = malloc(sizeof(MeciVolei*) * 10);

    FILE* f = fopen("meciuri.txt", "r");


    char cod[10], gazda[50], oaspete[50];
    int scorG, scorO;
    while (fscanf(f, "%s %s %s %d %d", cod, gazda, oaspete, &scorG, &scorO) == 5) {
        MeciVolei* m = initializareMeci(cod, gazda, oaspete, scorG, scorO);
        heap->vector[heap->dimensiune++] = m;
    }
    fclose(f);

    for (int i = heap->dimensiune / 2 - 1; i >= 0; i--)
        filtrareHeap(heap->vector, heap->dimensiune, i);

    printf("Heap initial:\n");
    afisareHeap(heap);

    printf("\nMeciuri cu scor peste 20: %d\n", numaraMeciuriCuScorPeste(heap, 20));

    heap = stergeMeciuriEchilibrate(heap);
    printf("\nHeap dupa stergerea meciurilor cu diferenta mai mica sau egala cu  2:\n");
    afisareHeap(heap);

    return 0;
}
